# Super Playing Card Game of cs193p lecture (Fall 2013-14)

written in Xcode 5.0.1 for iOS7.0+


### various versions are available via branches and tags:

[End of Lecture #7](http://cs193p.m2m.at/cs193p-lecture-7-animation-auto-layout-fall-2013-14/) -> [EndOfLecture7](https://github.com/m2mtech/SuperCard-2013-14/tree/EndOfLecture7)


