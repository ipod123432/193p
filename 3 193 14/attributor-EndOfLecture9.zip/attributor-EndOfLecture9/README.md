# Atributor Demo of cs193p lecture (Fall 2013-14)

written in Xcode 5.0.1 for iOS7.0+


### various versions are available via branches and tags:



[End of Lecture #9](http://cs193p.m2m.at/cs193p-lecture-9-animation-and-autolayout-fall-2013-14/) -> [EndOfLecture9](https://github.com/m2mtech/attributor/tree/EndOfLecture9)

[End of Lecture #6](http://cs193p.m2m.at/cs193p-lecture-6-views-and-gestures-fall-2013-14/) -> [EndOfLecture6](https://github.com/m2mtech/attributor/tree/EndOfLecture6)

[End of Lecture #5](http://cs193p.m2m.at/cs193p-lecture-5-view-controller-lifecycle-fall-2013-14/) -> [EndOfLecture5](https://github.com/m2mtech/attributor/tree/EndOfLecture5)