//
//  AttributorViewController.h
//  Attributor
//
//  Created by Martin Mandl on 09.11.13.
//  Copyright (c) 2013 m2m server software gmbh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AttributorViewController : UIViewController

@end
