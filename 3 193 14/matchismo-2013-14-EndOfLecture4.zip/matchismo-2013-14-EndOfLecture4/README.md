# Matchismo Playing Card Game of cs193p lecture (Fall 2013-14)

written in Xcode 5.0.1 for iOS7.0+


### various versions are available via branches and tags:

[End of Lecture #4](http://cs193p.m2m.at/cs193p-lecture-4-foundation-and-attributed-strings-fall-2013-14/) -> [EndOfLecture4](https://github.com/m2mtech/matchismo-2013-14/tree/EndOfLecture4)

[End of Lecture #3](http://cs193p.m2m.at/cs193p-lecture-3-objective-c-fall-2013-14/) -> [EndOfLecture3](https://github.com/m2mtech/matchismo-2013-14/tree/EndOfLecture3)

+ [Assignment #1 Taks #5](http://cs193p.m2m.at/cs193p-assignment-1-task-5-fall-2013-14/) -> [assignment1task5](https://github.com/m2mtech/matchismo-2013-14/tree/assignment1task5)
+ [Assignment #1 Taks #4](http://cs193p.m2m.at/cs193p-assignment-1-task-4-fall-2013-14/) -> [assignment1task4](https://github.com/m2mtech/matchismo-2013-14/tree/assignment1task4)
+ [Assignment #1 Taks #3](http://cs193p.m2m.at/cs193p-assignment-1-task-3-fall-2013-14/) -> [assignment1task3](https://github.com/m2mtech/matchismo-2013-14/tree/assignment1task3)
+ [Assignment #1 Taks #2](http://cs193p.m2m.at/cs193p-assignment-1-task-2-fall-2013-14/) -> [assignment1task2](https://github.com/m2mtech/matchismo-2013-14/tree/assignment1task2)

[End of Lecture #2](http://cs193p.m2m.at/cs193p-lecture-2-xcode-5-fall-2013-14/) -> [EndOfLecture2](https://github.com/m2mtech/matchismo-2013-14/tree/EndOfLecture2)