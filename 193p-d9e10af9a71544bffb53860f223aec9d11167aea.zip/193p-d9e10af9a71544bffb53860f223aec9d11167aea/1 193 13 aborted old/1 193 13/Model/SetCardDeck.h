//
//  SetCardDeck.h
//  1 193 13
//
//  Created by Roger on 11/30/13.
//  Copyright (c) 2013 fleija. All rights reserved.
//

#import "Deck.h"

@interface SetCardDeck : Deck

@end
