//
//  SetCardGameViewController.h
//  1 193 13
//
//  Created by Roger on 11/29/13.
//  Copyright (c) 2013 fleija. All rights reserved.
//

#import "CardGameViewController.h"

@interface SetCardGameViewController : CardGameViewController

@end
