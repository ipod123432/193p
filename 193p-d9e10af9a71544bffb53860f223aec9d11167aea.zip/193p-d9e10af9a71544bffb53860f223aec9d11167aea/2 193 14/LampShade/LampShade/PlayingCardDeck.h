//
//  PlayingCardDeck.h
//  LampShade
//
//  Created by Roger on 5/26/14.
//  Copyright (c) 2014 handWave. All rights reserved.
//

#import "Deck.h"

@interface PlayingCardDeck : Deck

@end
