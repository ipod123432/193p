//
//  CardGameViewController.h
//  Matchismo
//
//  Created by Roger Zou on 05.26.14.
//  Copyright (c) 2013 m2m server software gmbh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameViewController.h"
#import "PlayingCardDeck.h"


@interface CardGameViewController : GameViewController <UIAlertViewDelegate>




@end
