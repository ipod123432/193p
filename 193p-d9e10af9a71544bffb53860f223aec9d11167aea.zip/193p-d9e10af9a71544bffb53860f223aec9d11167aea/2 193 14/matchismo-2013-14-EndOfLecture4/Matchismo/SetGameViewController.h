//
//  SetGameViewController.h
//  Matchismo
//
//  Created by Roger on 5/27/14.
//  Copyright (c) 2014 m2m server software gmbh. All rights reserved.
//

#import "GameViewController.h"
#import "SetCardDeck.h"

@interface SetGameViewController : GameViewController

@end
