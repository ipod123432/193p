193p
====

stanford
