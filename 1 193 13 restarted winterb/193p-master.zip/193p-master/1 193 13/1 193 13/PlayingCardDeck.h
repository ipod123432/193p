//
//  PlayingCardDeck.h
//  Matchismo
//
//  Created by Martin Mandl on 25.01.13.
//  Copyright (c) 2013 m2m server software gmbh. All rights reserved.
//

#import "Deck.h"

@interface PlayingCardDeck : Deck

@end
