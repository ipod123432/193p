//
//  PlayingCardGameViewController.h
//  1 193 13
//
//  Created by Roger on 11/28/13.
//  Copyright (c) 2013 fleija. All rights reserved.
//

#import "CardGameViewController.h"



@interface PlayingCardGameViewController : CardGameViewController

@end
